﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WallEnemies : MonoBehaviour
{
    [SerializeField] Transform[] positions;

    void Start()
    {
        foreach (Transform position in positions) {

        }
    }
}
