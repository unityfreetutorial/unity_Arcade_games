﻿public enum Screens
{
    Main,
    Play,
    End,
    Return
}