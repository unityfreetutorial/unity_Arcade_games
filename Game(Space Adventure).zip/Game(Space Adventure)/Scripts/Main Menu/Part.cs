﻿using UnityEngine;

public class Part : MonoBehaviour
{
    public int price;
}
