﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Audio;
using System;

public class AudioManager1 : MonoBehaviour
{
    public Sound1[] sounds;

    public static AudioManager1 instance;

    private void Awake()
    {
        //DontDestroyOnLoad(gameObject);

        if (instance == null)
            instance = this;
        else if (instance != this)
            Destroy(gameObject);
    }

    private void Start()
    {
        foreach (Sound1 s in sounds)
        {
            s.source = gameObject.AddComponent<AudioSource>();
            s.source.clip = s.clip;
            s.source.volume = s.volume;
            s.source.loop = s.loop;
        }
    }

    public void Play(string name)
    {
        Sound1 s = Array.Find(sounds, sounds => sounds.name == name);

        if (s == null)
        {
            Debug.LogError("Sound " + name + " not found");
            return;
        }

        s.source.Play();
    }
}
