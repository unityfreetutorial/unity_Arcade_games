﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Pickups : MonoBehaviour
{
    public GameObject burstParticlesPrefab;

    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Player")
        {
            AudioManager1.instance.Play("Pickup");
            GameManager1.instance.IncrementScore(2);

            Instantiate(burstParticlesPrefab, transform.position, Quaternion.identity);
            this.gameObject.SetActive(false);
        }
    }
}
