﻿public enum TileContent
{
    Empty, Apple, Bonus, SnakesHead, SnakesBody, SnakesTail, SnakesBulge, SnakesL, SnakesLBulged 
}
