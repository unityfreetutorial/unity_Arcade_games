using UnityEngine;
using UnityEngine.SceneManagement;

public enum State { MainMenu, PauseMenu, Playing };

public class GameManager_slicer : MonoSingleton<GameManager_slicer>
{
    public State State { get; private set; } = State.MainMenu;

    [SerializeField] int score;
    [SerializeField] int lives = 3;
    int actualScore;
    int actualLives;

    [SerializeField] UIManager_slicer uiManager;
    public GameObject panel_loading;

	void Start()
	{
        actualScore = score;
        actualLives = lives;
	}

	void Update()
	{
		if (Input.GetKeyDown(KeyCode.Escape))
		{
            if (State == State.Playing)
			{
                PauseGame();
			}
			else if (State == State.PauseMenu)
			{
                ContinueGame();
			}
		}
	}

	public void StartGame()
	{
        actualScore = score;
        actualLives = lives;
        uiManager.UpdateScore(score);
        uiManager.UpdateBestScore(PlayerPrefs.GetInt("bestscore_slicer"));
        uiManager.UpdateLives(lives);
        uiManager.DisplayMainMenu(false);
        uiManager.DisplayHUD(true);
        State = State.Playing;
	}

    public void ExitGame()
	{
        panel_loading.SetActive(true); 
        SceneManager.LoadSceneAsync(0 , LoadSceneMode.Single); 
	}

    public void PauseGame()
	{
        State = State.PauseMenu;
        Time.timeScale = 0f;
        uiManager.DisplayPauseMenu(true);
	}

    public void ContinueGame()
	{
        uiManager.DisplayPauseMenu(false);
        Time.timeScale = 1f;
        State = State.Playing;
    }

    public void GameOver()
	{
        if (State == State.Playing)
		{
            if (actualScore > PlayerPrefs.GetInt("bestscore_slicer"))
                PlayerPrefs.SetInt("bestscore_slicer", actualScore);
            State = State.MainMenu;
            uiManager.DisplayHUD(false);
            uiManager.DisplayMainMenu(true);
            AdManager.instance.show_ads_ingames();
        }
	}

    public void AddScore(int scoreToAdd)
	{
        actualScore += scoreToAdd;
        uiManager.UpdateScore(actualScore);
	}

    public void RemoveAllLives()
	{
        actualLives = 0;
        uiManager.UpdateLives(actualLives);
        GameOver();
    }

    public void RemoveLife()
	{
        actualLives--;
        uiManager.UpdateLives(actualLives);
        if (actualLives == 0)
		{
            GameOver();
		}
	}
}
