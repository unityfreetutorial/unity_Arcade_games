using TMPro;
using UnityEngine;

public class UIController_tetris : MonoBehaviour
{
    [Header("End Game")]
    [SerializeField]
    private GameObject endGameUI;
    [SerializeField]
    private TextMeshProUGUI levelText;
    [SerializeField]
    private TextMeshProUGUI nextLevelBtnText;

    [SerializeField]
    private GameObject endGameFailUI;
    [SerializeField]
    private TextMeshProUGUI endGameFailText;

    [SerializeField]
    private GameObject gameStartUI;

    public GameObject panel_loading;

    private void Start()
    {
        levelText.text = "Level " + PlayerPrefs.GetInt("Level_tetris", 1) + " Success!";
        nextLevelBtnText.text = "GO Level " + (PlayerPrefs.GetInt("Level_tetris", 1) + 1) + " !";
        endGameUI.SetActive(false);

        endGameFailText.text = "Level " + PlayerPrefs.GetInt("Level_tetris", 1) + " FAILED!";
        endGameFailUI.SetActive(false);

        if (PlayerPrefs.GetInt("IsFirstTimePlay_tetris", 1) == 0)
            gameStartUI.SetActive(false);

    }

    private void OnEnable()
    {
        if(GameObject.FindGameObjectWithTag("Player")!=null)
          GameObject.FindGameObjectWithTag("Player").GetComponent<PlayerController_tetris>().endGameEvent += showEndGameUI;
    }
    private void OnDisable()
    {
        if(GameObject.FindGameObjectWithTag("Player")!=null)
          GameObject.FindGameObjectWithTag("Player").GetComponent<PlayerController_tetris>().endGameEvent -= showEndGameUI;
    }
    public void showEndGameUI(object sender, PlayerController_tetris.endGameEventArgs e)
    {
        if (e.IsGameSuccess)
        {
            endGameUI.SetActive(true);
        }
        else
        {
            endGameFailUI.SetActive(true);
        }
    }
    public void startGame()
    {
        gameStartUI.SetActive(false);
        endGameFailUI.SetActive(false);
        PlayerPrefs.SetInt("IsFirstTimePlay_tetris", 0);
        PlayerPrefs.Save();
        Camera.main.GetComponent<GameController_tetris>().resetGame();

    }
    public void startNextGame()
    {
        endGameUI.SetActive(false);
        PlayerPrefs.SetInt("Level_tetris", PlayerPrefs.GetInt("Level_tetris", 1) + 1);
        PlayerPrefs.Save();
        Camera.main.GetComponent<GameController_tetris>().restartGame();
    }

    public void exitGame()
    {
        panel_loading.SetActive(true);
        PlayerPrefs.SetInt("IsFirstTimePlay_tetris", 1);
        PlayerPrefs.Save();
        UnityEngine.SceneManagement.SceneManager.LoadScene(0);
    }
    private void OnApplicationQuit()
    {
        PlayerPrefs.SetInt("IsFirstTimePlay_tetris", 1);
        PlayerPrefs.Save();
    }
}
