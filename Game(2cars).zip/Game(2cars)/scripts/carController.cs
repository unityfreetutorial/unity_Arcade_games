﻿using UnityEngine;
using UnityEngine.UI;
//using System.Collections;

public class carController : MonoBehaviour {
    public float rSpawnPosR = -1.87f;
    public float rSpawnPosL = -0.607f;
    public float bSpawnPosR = 1.867f;
    public float bSpawnPosL = 0.607f;
    public int redFlag = 0;
    public int blueFlag = 0;
    public uiManager ui;
    public AudioSource audio_food , audio_gameover;
    
  
    void OnCollisionEnter2D(Collision2D col) {
        if (col.gameObject.tag=="food") {
            audio_food.Play();
            ui.score += 1;
            ui.currentScore.text = ui.score.ToString();
            Destroy(col.gameObject);
        }

        else{
            if (ui.score > ui.uHighScore) {
                PlayerPrefs.SetInt("HighScore_twocars",ui.score);
            }
            audio_gameover.Play();
            ui.highScore.text = "High Score: "+ PlayerPrefs.GetInt("HighScore_twocars").ToString();
           
            AdManager.instance.show_ads_ingames();

            Destroy(gameObject);
            ui.gameOverAcivate();
        }
    }


    public void rMove(){
        if (redFlag == 0) {
            transform.position = Vector3.MoveTowards(transform.position,new Vector3(rSpawnPosL, transform.position.y, transform.position.z), 5f);
            redFlag = 1;
        } else if (redFlag==1) {
            transform.position = Vector3.MoveTowards(transform.position, new Vector3(rSpawnPosR, transform.position.y, transform.position.z), 5f);
            redFlag = 0;
        }
        
    }
    public void bMove()
    {
        if (redFlag == 0)
        {
            transform.position = Vector3.MoveTowards(transform.position, new Vector3(bSpawnPosL, transform.position.y, transform.position.z), 5f);
            redFlag = 1;
        }
        else if (redFlag == 1)
        {
            transform.position = Vector3.MoveTowards(transform.position, new Vector3(bSpawnPosR, transform.position.y, transform.position.z), 5f);
            redFlag = 0;
        }

    }

}


