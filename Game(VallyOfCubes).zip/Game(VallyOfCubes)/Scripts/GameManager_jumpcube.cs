﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameManager_jumpcube : MonoBehaviour {

	public GameObject pillarPrefab;
	public GameObject pillarHolder; 
	public GameObject cube;
	public GameObject loseUI;
	public Text scoreText, Jump_Text, finalScoreText, bestScoreText, jumpsText;
	public int pillarsToMake = 20;
	public float minDistance = 3f, maxDistance = 5f;
	public int score, jumps;
	Vector3 spawnPosition;
	bool gameOver;
	private int count_cube=21;
	public AudioSource audio;
	public GameObject panel_loading;

	// Use this for initialization
	void Start () {
		spawnPosition = transform.position;
		makingPillars(pillarsToMake);
		score = 0;
		gameOver = false;
	}

	void FixedUpdate(){
		if(cube.transform.position.y < -13 && !gameOver){
			gameOver = true;
			Camera.main.gameObject.GetComponent<CameraBehaviour>().gameOver = true;
			StartCoroutine(loseGame());
		}
	}

	public void scoreUp(int points){
		score+= points;
		jumps++;
		if(points>1)
		{
          scoreText.text = "Score: "+score;
		  Jump_Text.text = "Jump: "+(jumps-1);
		  audio.Play();

		  for (int i = 0; i < pillarHolder.transform.childCount; i++)
			{
				int child_score = pillarHolder.transform.GetChild(i).gameObject.GetComponent<PillarBehaviour>().score;
				if(child_score<points)
				{
				  Destroy(pillarHolder.transform.GetChild(i).gameObject);
				}
			}

		}

        makingPillars_later(count_cube++);
		
		
	}

	void makingPillars(int count){
		for(int i = 0; i < count; i++){
			GameObject tempPillar = Instantiate(pillarPrefab, spawnPosition, pillarPrefab.transform.rotation);
			tempPillar.transform.SetParent(pillarHolder.transform);
			tempPillar.GetComponent<PillarBehaviour>().gameManager = this;
			tempPillar.GetComponent<PillarBehaviour>().cube = cube;
			tempPillar.GetComponent<PillarBehaviour>().score = i+1;
			spawnPosition = new Vector3(spawnPosition.x, Random.Range(-8,-4), 
							spawnPosition.z + Random.Range(minDistance, maxDistance));
		}	
	}
	void makingPillars_later(int score){

		GameObject tempPillar = Instantiate(pillarPrefab, spawnPosition, pillarPrefab.transform.rotation);
		tempPillar.transform.SetParent(pillarHolder.transform);
		tempPillar.GetComponent<PillarBehaviour>().gameManager = this;
		tempPillar.GetComponent<PillarBehaviour>().cube = cube;
		tempPillar.GetComponent<PillarBehaviour>().score = score;
		spawnPosition = new Vector3(spawnPosition.x, Random.Range(-8,-4), 
						spawnPosition.z + Random.Range(minDistance, maxDistance));
		
	}

	IEnumerator loseGame(){
		cube.GetComponent<CubeBehaviour>().loseGame = true;
		for(int i = 0; i >= 0; i--){
			float k = (float) i/10;
			//pillarHolder.transform.localScale = new Vector3(k,k,k);
			yield return new WaitForSeconds(.05f);
		}
		//pillarHolder.SetActive(false);
		if(score > PlayerPrefs.GetInt("bestScore_jumpcube",0)) 
		  PlayerPrefs.SetInt("bestScore_jumpcube",score);
		loseUI.SetActive(true);
		finalScoreText.GetComponent<Text>().text = ""+ score;
		bestScoreText.GetComponent<Text>().text = "Best score:"+ PlayerPrefs.GetInt("bestScore_jumpcube",0);
		jumpsText.GetComponent<Text>().text = "Jumps:"+ (jumps-1);
		AdManager.instance.show_ads_ingames();
		
	}

	public void restart(){
		SceneManager.LoadSceneAsync(40 , LoadSceneMode.Single);
	}
	public void home(){
		panel_loading.SetActive(true);
		SceneManager.LoadSceneAsync(0 , LoadSceneMode.Single);
	}
}
