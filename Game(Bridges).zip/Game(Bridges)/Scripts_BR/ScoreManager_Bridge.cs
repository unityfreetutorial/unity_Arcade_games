﻿using UnityEngine;
using UnityEngine.UI;

public class ScoreManager_Bridge : MonoBehaviour
{
    public static ScoreManager_Bridge Instance { get; set; }
    public Text currentScoreLabel, highScoreLabel, currentScoreGameOverLabel, highScoreGameOverLabel;

    public int currentScore, highScore;
    // Start is called before the first frame update

    bool counting;

    void Awake()
    {
       // DontDestroyOnLoad(this);

        if (Instance == null)
            Instance = this;
        else
            Destroy(gameObject);
    }

    //init and load highscore
    void Start()
    {
        if (!PlayerPrefs.HasKey("HighScore_Bridge"))
            PlayerPrefs.SetInt("HighScore_Bridge", 0);

        highScore = PlayerPrefs.GetInt("HighScore_Bridge");

        UpdateHighScore();
        ResetCurrentScore();
    }

    //save and update highscore
    void UpdateHighScore()
    {
        if (currentScore > highScore)
            highScore = currentScore;

        highScoreLabel.text = highScore.ToString();
        PlayerPrefs.SetInt("HighScore_Bridge", highScore);
    }

    //update currentscore
    public void UpdateScore(int value)
    {
        currentScore += value;
        currentScoreLabel.text = currentScore.ToString();
    }

    //reset current score
    public void ResetCurrentScore()
    {
        currentScore = 0;
        UpdateScore(0);
    }

    //update gameover scores
    public void UpdateScoreGameover()
    {
        UpdateHighScore();

        currentScoreGameOverLabel.text = currentScore.ToString();
        highScoreGameOverLabel.text = highScore.ToString();
    }
}
