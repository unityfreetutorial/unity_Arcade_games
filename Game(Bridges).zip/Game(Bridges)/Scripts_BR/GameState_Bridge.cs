﻿public enum GameState_Bridge {
    MENU,
    PLAYING,
    PAUSED,
    GAMEOVER
}
