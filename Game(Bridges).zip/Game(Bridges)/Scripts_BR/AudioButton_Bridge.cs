﻿using UnityEngine;
using UnityEngine.UI;

public class AudioButton_Bridge : MonoBehaviour
{
    public bool efx;
    public Sprite musicOnSprite, musicOffSprite, efxOnSprite, efxOffSprite;
    public Image spriteButton;


    //set button sprite
    void Start()
    {
        SetButton();
    }

    public void MusicButtonClicked()
    {
        AudioManager_brige.Instance.MuteMusic();
        AudioManager_brige.Instance.PlayEffects(AudioManager_brige.Instance.buttonClick);
        SetButton();
    }

    public void EfxButtonClicked()
    {
        AudioManager_brige.Instance.MuteEfx();
        AudioManager_brige.Instance.PlayEffects(AudioManager_brige.Instance.buttonClick);
        SetButton();
    }

    void SetButton()
    {
        if ((!AudioManager_brige.Instance.IsMusicMute() && !efx) || (!AudioManager_brige.Instance.IsEfxMute() && efx))
            if (efx)
                spriteButton.sprite = efxOnSprite;
            else
                spriteButton.sprite = musicOnSprite;
        else
            if (efx)
                spriteButton.sprite = efxOffSprite;
            else
                spriteButton.sprite = musicOffSprite;
    }
}
