﻿namespace RectangleTrainer.ChromaTower.Engine
{
    public struct HitResult
    {
        public bool playerDead;
        public bool successfulHit;
    }
}
