using UnityEngine;

public class Boundary : MonoBehaviour
{
    public float MinAngle;
    public float MaxAngle;
}
