﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;


public class PlayButton : MonoBehaviour
{
    public GameObject panel_loading;

    public void StartButtonClicked()
    {
       SceneManager.LoadSceneAsync(10 , LoadSceneMode.Single); 
    }

    public void MainMenuButtonClicked()
    {
       SceneManager.LoadSceneAsync(9 , LoadSceneMode.Single); 
    }

    public void click_menu()
    {
       panel_loading.SetActive(true); 
       SceneManager.LoadSceneAsync(0 , LoadSceneMode.Single); 
    }
}
