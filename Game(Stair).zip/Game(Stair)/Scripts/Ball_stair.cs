using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ball_stair : MonoBehaviour
{

    [SerializeField]
    private float startSpeed, forceMultiplier;

    private float acceleration, speed;
    public AudioSource audio;
    public AudioClip clip_Diamond , clip_spike , clip_combo;
    // Start is called before the first frame update
    void Start()
    {
        speed = startSpeed;
        acceleration = -startSpeed * forceMultiplier;
    }

    // Update is called once per frame
    void Update()
    {
        if (transform.localPosition.y < -1f)
            GameManager_stair.instance.GameOver();
    }

    private void FixedUpdate()
    {
        speed += acceleration * Time.fixedDeltaTime;
        Vector3 temp = new Vector3(0, speed * Time.fixedDeltaTime, 0);
        transform.localPosition += temp;
    }

    private void OnCollisionEnter(Collision collision)
    {
        speed = startSpeed;
        GameManager_stair.instance.SpawnBlock();
        if (!GameManager_stair.instance.hasGameStarted) return;
        if(collision.gameObject.CompareTag("Block"))
        {
            Destroy(collision.gameObject, 5f);
            GameManager_stair.instance.UpdateScore();
        }
        else if(collision.gameObject.CompareTag("Combo"))
        {
            Destroy(collision.gameObject);
            GameManager_stair.instance.UpdateCombo();
            audio.clip=clip_combo;
            audio.Play();
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if(other.CompareTag("Diamond"))
        {
            GameManager_stair.instance.UpdateDiamond();
            Destroy(other.gameObject);
            audio.clip=clip_Diamond;
            audio.Play();
        }
        if(other.CompareTag("Spike"))
        {
            GameManager_stair.instance.GameOver();
            audio.clip=clip_spike;
            audio.Play();
        }
    }

}
