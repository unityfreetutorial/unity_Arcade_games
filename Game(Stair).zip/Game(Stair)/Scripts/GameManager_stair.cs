using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.SceneManagement;

public class GameManager_stair : MonoBehaviour
{

    [SerializeField]
    private GameObject startButton, endPanel, blockPrefab,player;

    [SerializeField]
    private TMP_Text scoreText, diamondText, highScoreText, highScoreEndText;

    [SerializeField]
    private Vector3 startPos, offset;

    private int score, diamondCount, combo, highScore;

    public bool hasGameStarted;

    public static GameManager_stair instance;
    public GameObject panel_loading;

    private void Awake()
    {
        if (instance == null)
            instance = this;
        else
            Destroy(gameObject);

        Time.timeScale = 1f;
        hasGameStarted = false;
    }

    // Start is called before the first frame update
    void Start()
    {
        startButton.SetActive(true);
        endPanel.SetActive(false);

        score = 0;
        combo = 1;
        highScore = PlayerPrefs.HasKey("HighScore_stair") ? PlayerPrefs.GetInt("HighScore_stair") : 0;
        diamondCount = PlayerPrefs.HasKey("Diamonds_stair") ? PlayerPrefs.GetInt("Diamonds_stair") : 0;

        scoreText.text = score.ToString();
        diamondText.text = diamondCount.ToString();
        highScoreText.text = "BEST : " + highScore.ToString();

        for (int i = 0; i < 5; i++)
        {
            SpawnBlock();
        }
    }

    public void SpawnBlock()
    {
        GameObject tempBlock = Instantiate(blockPrefab);
        startPos += offset;
        tempBlock.transform.position = startPos;
    }

    public void UpdateDiamond()
    {
        diamondCount++;
        PlayerPrefs.SetInt("Diamonds_stair", diamondCount);
        diamondText.text = diamondCount.ToString();
    }

    public void UpdateScore()
    {
        combo = 1;
        score++;
        scoreText.text = score.ToString();
    }

    public void UpdateCombo()
    {
        combo++;
        score += combo;
        scoreText.text = score.ToString();
    }

    public void GameOver()
    {
        Time.timeScale = 0f;
        endPanel.SetActive(true);
        if(score > highScore)
        {
            highScore = score;
            PlayerPrefs.SetInt("HighScore_stair", highScore);
        }
        highScoreEndText.text = "BEST : " + highScore.ToString();
        AdManager.instance.show_ads_ingames();

    }

    public void GameStart()
    {
        startButton.SetActive(false);
        player.GetComponent<Player_stair>().hasGameStarted = true;
        hasGameStarted = true;
    }

    public void GameRestart()
    {
        SceneManager.LoadSceneAsync(12 , LoadSceneMode.Single);
    }

    public void GameQuit()
    {
       Time.timeScale = 1f; 
       panel_loading.SetActive(true); 
       SceneManager.LoadSceneAsync(0 , LoadSceneMode.Single); 
    }
}
